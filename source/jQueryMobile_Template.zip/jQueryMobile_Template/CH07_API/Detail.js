// JavaScript Document
alert("Detail");