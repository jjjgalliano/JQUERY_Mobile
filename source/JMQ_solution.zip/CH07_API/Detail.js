// JavaScript Document
$(document).on("pageshow", "#detail", detailPageShowHandler);

function detailPageShowHandler(){
	alert("Detail");
}